// // Your web app's Firebase configuration
// var firebaseConfig = {
//     apiKey: "AIzaSyBfeaxx6tdnMEfl8L2MPGZh8qpSkLZRM4c",
//     authDomain: "gratitudetoday-org.firebaseapp.com",
//     databaseURL: "https://gratitudetoday-org.firebaseio.com",
//     projectId: "gratitudetoday-org",
//     storageBucket: "gratitudetoday-org.appspot.com",
//     messagingSenderId: "500615815024",
//     appId: "1:500615815024:web:7f08556d45e459ec25b9b5"
//   };
//   // Initialize Firebase
//   firebase.initializeApp(firebaseConfig);