// const fs = require('fs')
// const readline = require('readline');



// fr.readAsText(fileList[0]);
// var CheckBlacklist = function() {};

// CheckBlacklist.prototype.check = function(postMessage) {
  
  
//   // fs.readFile('blacklist/blacklist.txt', 'utf8' , (err, data) => {
//   //   if (err) {
//   //     console.error(err)
//   //     return
//   //   }
//   //   console.log(postMessage)
//   //   console.log(data);


//   // })
//   const rl = readline.createInterface({
//     input: fs.createReadStream('blacklist/blacklist.txt'),
//     crlfDelay: Infinity
//   });
//   //split blacklist words
//   rl.on('line', (line) => {
//     //create array from lines
//     console.log(line)
    
//   })
  

// }

// module.exports = new CheckBlacklist();
