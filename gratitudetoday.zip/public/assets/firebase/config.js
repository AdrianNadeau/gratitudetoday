
  // // Your web app's Firebase configuration
  // // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  // var firebaseConfig = {
  //   apiKey: "AIzaSyCMP6_4RzRbqsHlMZVmZEtK_UkypLECXBY",
  //   authDomain: "gratitudetoday-2e630.firebaseapp.com",
  //   projectId: "gratitudetoday-2e630",
  //   storageBucket: "gratitudetoday-2e630.appspot.com",
  //   messagingSenderId: "957156185108",
  //   appId: "1:957156185108:web:2c7f59c145cfcce9f14301",
  //   measurementId: "G-8EPH5NWCK8"
  // };
  // // Initialize Firebase
  // firebase.initializeApp(firebaseConfig); 
  // firebase.analytics();
