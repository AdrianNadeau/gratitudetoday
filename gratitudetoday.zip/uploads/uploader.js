// Copyright 2019 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
const { initializeApp, cert } = require('firebase-admin/app');
const { getStorage } = require('firebase-admin/storage');

const serviceAccount = require('../gratitudetoday-2e630-firebase-adminsdk-sx0pq-b907b6e239.json');

initializeApp({
  credential: cert(serviceAccount),
  storageBucket: 'gratiudetoday---dev.appspot.com'
});

const bucket = getStorage().bucket();

// 'bucket' is an object defined in the @google-cloud/storage library.
// See https://googlecloudplatform.github.io/google-cloud-node/#/docs/storage/latest/storage/bucket
// for more details.

function main(
    bucketName = 'gratiudetoday---dev.appspot.com',
    filePath = 'C:/anadeau/58zDZ0j923nsUSLBvU67j3JzrEE60IHG.jpg',
    destFileName = '58zDZ0j923nsUSLBvU67j3JzrEE60IHG.jpg'
  ) {
    // [START storage_upload_file]
    /**
     * TODO(developer): Uncomment the following lines before running the sample.
     */
    // The ID of your GCS bucket
    // const bucketName = 'your-unique-bucket-name';
  
    // The path to your file to upload
    // const filePath = 'path/to/your/file';
  
    // The new ID for your GCS file
    // const destFileName = 'your-new-file-name';
  
    // Imports the Google Cloud client library
    const {Storage} = require('@google-cloud/storage');
  
    // Creates a client
    const storage = new Storage();
  
    async function uploadFile() {
      await storage.bucket(bucketName).upload(filePath, {
        destination: destFileName,
      });
  
      console.log(`${filePath} uploaded to ${bucketName}`);
    }
  
    uploadFile().catch(console.error);
    // [END storage_upload_file]
  }
  
  main(...process.argv.slice(2));
